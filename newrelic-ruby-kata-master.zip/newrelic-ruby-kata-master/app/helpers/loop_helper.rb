module LoopHelper
end
