module ManyAssetsHelper
end
