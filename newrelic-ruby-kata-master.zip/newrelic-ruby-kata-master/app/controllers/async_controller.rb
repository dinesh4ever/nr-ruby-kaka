class AsyncController < ApplicationController
  def index
  end
end
