class Car < ActiveRecord::Base
  has_many :drivers
end
