class PageContent < ActiveRecord::Base
  belongs_to :web_site
end
