class Icon < ActiveRecord::Base
  belongs_to :web_site
end
