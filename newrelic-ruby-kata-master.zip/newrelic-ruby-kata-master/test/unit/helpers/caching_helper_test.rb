require 'test_helper'

class CachingHelperTest < ActionView::TestCase
end
