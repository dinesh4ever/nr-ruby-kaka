require 'test_helper'

class BigListHelperTest < ActionView::TestCase
end
