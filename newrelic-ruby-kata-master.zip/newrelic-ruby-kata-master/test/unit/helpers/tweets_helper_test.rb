require 'test_helper'

class TweetsHelperTest < ActionView::TestCase
end
