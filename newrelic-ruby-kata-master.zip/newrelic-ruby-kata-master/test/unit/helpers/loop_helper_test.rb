require 'test_helper'

class LoopHelperTest < ActionView::TestCase
end
