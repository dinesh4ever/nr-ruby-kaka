require 'test_helper'

class AsyncHelperTest < ActionView::TestCase
end
