#!/bin/bash

cd /home/ec2-user/newrelic-ruby-kata

bundle exec rails server -b 0.0.0.0