# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
NewrelicRubyKata::Application.config.secret_token = 'a7f998e63bce21d9e9c6c421afb744c16c3df4e7a12b25d6024336b98d594005a687676957c0486966c5458307d615cab66d6b1b72a2a87579abdb59be2fc4c7'
